// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283


#include "diag.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

// Arquivo de saída para trace 
static FILE *trace_file = NULL;

void diag_set_trace_file(FILE *f) {
    trace_file = f;
}

const char *diag_token_name(TokenType t) {
    switch (t) {
        case sIDENTIF:    return "sIDENTIF";
        case sCTEINT:     return "sCTEINT";
        case sCTECHAR:    return "sCTECHAR";
        case sSTRING:     return "sSTRING";
        case sBOOL:       return "sBOOL";
        case sCHAR:       return "sCHAR";
        case sINT:        return "sINT";
        case sIF:         return "sIF";
        case sELSE:       return "sELSE";
        case sWHILE:      return "sWHILE";
        case sLOOP:       return "sLOOP";
        case sUNTIL:      return "sUNTIL";
        case sFOR:        return "sFOR";
        case sTO:         return "sTO";
        case sSTEP:       return "sSTEP";
        case sDO:         return "sDO";
        case sMATCH:      return "sMATCH";
        case sWHEN:       return "sWHEN";
        case sOTHERWISE:  return "sOTHERWISE";
        case sSTART:      return "sSTART";
        case sEND:        return "sEND";
        case sGLOBALS:    return "sGLOBALS";
        case sLOCALS:     return "sLOCALS";
        case sFN:         return "sFN";
        case sPROC:       return "sPROC";
        case sRET:        return "sRET";
        case sPRINT:      return "sPRINT";
        case sSCAN:       return "sSCAN";
        case sTRUE:       return "sTRUE";
        case sFALSE:      return "sFALSE";
        case sMODULE:     return "sMODULE";
        case sMAIN:       return "sMAIN";
        case sSOMA:       return "sSOMA";
        case sSUBRAT:     return "sSUBRAT";
        case sMULT:       return "sMULT";
        case sDIV:        return "sDIV";
        case sIGUAL:      return "sIGUAL";
        case sDIFERENTE:  return "sDIFERENTE";
        case sMAIOR:      return "sMAIOR";
        case sMAIORIG:    return "sMAIORIG";
        case sMENOR:      return "sMENOR";
        case sMENORIG:    return "sMENORIG";
        case sAND:        return "sAND";
        case sOR:         return "sOR";
        case sNEG:        return "sNEG";
        case sATRIB:      return "sATRIB";
        case sPTOPTO:     return "sPTOPTO";
        case sIMPLIC:     return "sIMPLIC";
        case sPONTO_VIRG: return "sPONTO_VIRG";
        case sVIRGULA:    return "sVIRGULA";
        case sDOIS_PONTOS:return "sDOIS_PONTOS";
        case sABRE_PAR:   return "sABRE_PAR";
        case sFECHA_PAR:  return "sFECHA_PAR";
        case sABRE_COLCH: return "sABRE_COLCH";
        case sFECHA_COLCH:return "sFECHA_COLCH";
        case sEOF:        return "sEOF";
        case sERRO:       return "sERRO";
        default:          return "sINDEFINIDO";
    }
}

void diag_error(int linha, const char *esperado, const Token *encontrado) {
    fprintf(stderr,
            "\nERRO (linha %d): esperado '%s',"
            " encontrado '%s' [%s]\n",
            linha,
            esperado,
            encontrado->lexema,
            diag_token_name(encontrado->categoria));
    exit(1);
}

void diag_info(const char *fmt, ...) {
    if (!trace_file) return;   
    va_list ap;
    va_start(ap, fmt);
    vfprintf(trace_file, fmt, ap);
    va_end(ap);
}
