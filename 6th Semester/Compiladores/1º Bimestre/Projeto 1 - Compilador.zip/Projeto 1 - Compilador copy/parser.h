// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef PARSER_H
#define PARSER_H


void parse_program(void);

#endif 
