// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#include "parser.h"
#include "lex.h"
#include "diag.h"
#include "symtab.h"
#include "log.h"
#include "opt.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static Token la;                               
static Token la2;         
static int   has_la2 = 0; 
static int   indent  = 0; 

static void advance(void) {
    if (has_la2) {
        la      = la2;
        has_la2 = 0;
    } else {
        la = lex_next();
    }
    if (opts_get()->show_tokens)
        log_token(&la);
}

static Token peek(void) {
    if (!has_la2) {
        la2     = lex_next();
        has_la2 = 1;
    }
    return la2;
}


static void check(TokenType expected, const char *desc) {
    if (la.categoria != expected)
        diag_error(la.linha, desc, &la);
    advance();
}


static void enter_rule(const char *name) {
    if (opts_get()->show_trace) {
        for (int i = 0; i < indent; i++) diag_info("  ");
        diag_info("<%s>\n", name);
        indent++;
    }
}

static void exit_rule(const char *name) {
    if (opts_get()->show_trace) {
        indent--;
        for (int i = 0; i < indent; i++) diag_info("  ");
        diag_info("</%s>\n", name);
    }
}

static void parse_ini(void);
static void parse_glob(void);
static void parse_decls(SymScope scope);
static SymType parse_tpo(int *arr_size);
static void parse_locs(void);
static void parse_param(int *pcount);
static void parse_func(void);
static void parse_user_proc(void);
static void parse_princ(void);
static void parse_bco(void);
static void parse_cmd(void);
static void parse_out(void);
static void parse_inp(void);
static void parse_if(void);
static void parse_mat(void);
static void parse_witem(void);
static void parse_fr(void);
static void parse_wh_body(void);
static void parse_rpt_body(void);
static void parse_ret(void);
static void parse_elem(void);
static void parse_expr(void);
static void parse_exlog(void);
static void parse_exrel(void);
static void parse_exari(void);
static void parse_exarp(void);
static void parse_fact(void);


void parse_program(void) {
    advance();
    parse_ini();
}


static void parse_ini(void) {
    enter_rule("ini");

    check(sMODULE, "module");
    check(sIDENTIF, "nome do modulo");
    check(sPONTO_VIRG, ";");

    if (la.categoria == sGLOBALS)
        parse_glob();

    while (la.categoria == sFN ||
           (la.categoria == sPROC && peek().categoria != sMAIN)) {
        if (la.categoria == sFN)
            parse_func();
        else
            parse_user_proc();
    }

    parse_princ();

    if (la.categoria != sEOF)
        diag_error(la.linha, "fim de arquivo", &la);

    exit_rule("ini");
}


static void parse_glob(void) {
    enter_rule("glob");
    check(sGLOBALS, "globals");
    ts_set_scope_path("global");
    while (la.categoria == sIDENTIF)
        parse_decls(SCOPE_GLOBAL);
    exit_rule("glob");
}


static void parse_decls(SymScope scope) {
    enter_rule("decls");

    char names[64][256];
    int  n = 0;

    strncpy(names[n++], la.lexema, 255);
    check(sIDENTIF, "identificador");

    while (la.categoria == sVIRGULA) {
        advance();
        strncpy(names[n++], la.lexema, 255);
        check(sIDENTIF, "identificador");
    }

    check(sDOIS_PONTOS, ":");

    int arr_size = 0;
    SymType type = parse_tpo(&arr_size);

    check(sPONTO_VIRG, ";");

    for (int i = 0; i < n; i++) {
        if (!ts_insert(names[i], CAT_VAR, type, scope, arr_size)) {
            Token fake = { sERRO, "", la.linha };
            strncpy(fake.lexema, names[i], 255);
            diag_error(la.linha,
                       "identificador unico (ja declarado neste escopo)",
                       &fake);
        }
    }

    exit_rule("decls");
}


static SymType parse_tpo(int *arr_size) {
    enter_rule("tpo");
    SymType base = TYP_INT;
    *arr_size = 0;

    switch (la.categoria) {
        case sINT:  advance(); base = TYP_INT;  break;
        case sBOOL: advance(); base = TYP_BOOL; break;
        case sCHAR: advance(); base = TYP_CHAR; break;
        default:
            diag_error(la.linha, "tipo (int, bool ou char)", &la);
    }

    if (la.categoria == sABRE_COLCH) {
        advance();
        *arr_size = atoi(la.lexema);
        check(sCTEINT, "tamanho do vetor");
        check(sFECHA_COLCH, "]");
        if      (base == TYP_INT)  base = TYP_ARRAY_INT;
        else if (base == TYP_BOOL) base = TYP_ARRAY_BOOL;
        else                       base = TYP_ARRAY_CHAR;
    }

    exit_rule("tpo");
    return base;
}


static void parse_locs(void) {
    enter_rule("locs");
    check(sLOCALS, "locals");
    while (la.categoria == sIDENTIF)
        parse_decls(SCOPE_LOCAL);
    exit_rule("locs");
}


static void parse_param(int *pcount) {
    enter_rule("param");
    *pcount = 0;

    do {
        char pname[256];
        strncpy(pname, la.lexema, 255);
        check(sIDENTIF, "nome do parametro");
        check(sDOIS_PONTOS, ":");
        int dummy = 0;
        SymType pt = parse_tpo(&dummy);
        ts_insert(pname, CAT_PARAM, pt, SCOPE_LOCAL, dummy);
        (*pcount)++;
    } while (la.categoria == sVIRGULA && (advance(), 1));

    exit_rule("param");
}


static void parse_func(void) {
    enter_rule("func");
    check(sFN, "fn");

    char fname[256];
    strncpy(fname, la.lexema, 255);
    check(sIDENTIF, "nome da funcao");

    ts_open_scope();
    char spath[128];
    snprintf(spath, sizeof(spath), "fn:%s.locals", fname);
    ts_set_scope_path(spath);

    check(sABRE_PAR, "(");
    int pcount = 0;
    if (la.categoria != sFECHA_PAR)
        parse_param(&pcount);
    check(sFECHA_PAR, ")");
    check(sDOIS_PONTOS, ":");

    int dummy = 0;
    SymType ret = parse_tpo(&dummy);

    ts_insert(fname, CAT_FUNC, ret, SCOPE_GLOBAL, pcount);

    if (la.categoria == sLOCALS)
        parse_locs();

    parse_bco();
    ts_close_scope();
    exit_rule("func");
}


static void parse_user_proc(void) {
    enter_rule("proc");
    check(sPROC, "proc");

    char pname[256];
    strncpy(pname, la.lexema, 255);
    check(sIDENTIF, "nome do procedimento");

    ts_open_scope();
    char spath[128];
    snprintf(spath, sizeof(spath), "proc:%s.locals", pname);
    ts_set_scope_path(spath);

    check(sABRE_PAR, "(");
    int pcount = 0;
    if (la.categoria != sFECHA_PAR)
        parse_param(&pcount);
    check(sFECHA_PAR, ")");

    ts_insert(pname, CAT_PROC, TYP_NONE, SCOPE_GLOBAL, pcount);

    if (la.categoria == sLOCALS)
        parse_locs();

    parse_bco();
    ts_close_scope();
    exit_rule("proc");
}


static void parse_princ(void) {
    enter_rule("princ");
    check(sPROC, "proc");
    check(sMAIN,  "main");
    check(sABRE_PAR, "(");
    check(sFECHA_PAR, ")");

    ts_open_scope();
    ts_set_scope_path("proc:main.locals");

    if (la.categoria == sLOCALS)
        parse_locs();

    parse_bco();
    ts_close_scope();
    exit_rule("princ");
}


static void parse_bco(void) {
    enter_rule("bco");
    check(sSTART, "start");

    while (la.categoria != sEND && la.categoria != sEOF) {
        parse_cmd();
        check(sPONTO_VIRG, ";");
    }

    check(sEND, "end");
    exit_rule("bco");
}


static void parse_cmd(void) {
    enter_rule("cmd");

    switch (la.categoria) {
        case sPRINT: parse_out(); break;
        case sSCAN:  parse_inp(); break;
        case sIF:    parse_if();  break;
        case sMATCH: parse_mat(); break;
        case sFOR:   parse_fr();  break;
        case sRET:   parse_ret(); break;
        case sSTART: parse_bco(); break;

        case sLOOP:
            advance();
            if (la.categoria == sWHILE)
                parse_wh_body();
            else
                parse_rpt_body();
            break;

        case sIDENTIF: {
            advance();   

            if (la.categoria == sABRE_PAR) {
                advance();
                if (la.categoria != sFECHA_PAR) {
                    parse_expr();
                    while (la.categoria == sVIRGULA) {
                        advance();
                        parse_expr();
                    }
                }
                check(sFECHA_PAR, ")");

            } else if (la.categoria == sATRIB) {
                advance();
                parse_elem();

            } else if (la.categoria == sABRE_COLCH) {
                advance();
                if (la.categoria == sCTEINT || la.categoria == sIDENTIF)
                    advance();
                else
                    diag_error(la.linha, "indice (inteiro ou identificador)", &la);
                check(sFECHA_COLCH, "]");
                check(sATRIB, ":=");
                parse_elem();

            } else {
                diag_error(la.linha, ":= ou ( apos identificador", &la);
            }
            break;
        }

        default:
            diag_error(la.linha, "comando", &la);
    }

    exit_rule("cmd");
}


static void parse_out(void) {
    enter_rule("out");
    check(sPRINT, "print");
    check(sABRE_PAR, "(");
    parse_elem();
    while (la.categoria == sVIRGULA) {
        advance();
        parse_elem();
    }
    check(sFECHA_PAR, ")");
    exit_rule("out");
}


static void parse_inp(void) {
    enter_rule("inp");
    check(sSCAN, "scan");
    check(sABRE_PAR, "(");
    check(sIDENTIF, "variavel");
    if (la.categoria == sABRE_COLCH) {
        advance();
        if (la.categoria == sCTEINT || la.categoria == sIDENTIF)
            advance();
        else
            diag_error(la.linha, "indice", &la);
        check(sFECHA_COLCH, "]");
    }
    check(sFECHA_PAR, ")");
    exit_rule("inp");
}


static void parse_if(void) {
    enter_rule("if");
    check(sIF, "if");
    check(sABRE_PAR, "(");
    parse_expr();
    check(sFECHA_PAR, ")");
    parse_cmd();
    if (la.categoria == sELSE) {
        advance();
        parse_cmd();
    }
    exit_rule("if");
}


static void parse_witem(void) {
    if (la.categoria == sSUBRAT) advance();
    check(sCTEINT, "valor inteiro");
    if (la.categoria == sPTOPTO) {
        advance();
        if (la.categoria == sSUBRAT) advance();
        check(sCTEINT, "valor inteiro");
    }
}


static void parse_mat(void) {
    enter_rule("mat");
    check(sMATCH, "match");
    check(sABRE_PAR, "(");
    parse_expr();
    check(sFECHA_PAR, ")");

    while (la.categoria == sWHEN) {
        advance();
        parse_witem();
        while (la.categoria == sVIRGULA) {
            advance();
            parse_witem();
        }
        check(sIMPLIC, "=>");
        parse_cmd();
        check(sPONTO_VIRG, ";");
    }

    if (la.categoria == sOTHERWISE) {
        advance();
        check(sIMPLIC, "=>");
        parse_cmd();
        check(sPONTO_VIRG, ";");
    }

    check(sEND, "end");
    exit_rule("mat");
}


static void parse_fr(void) {
    enter_rule("fr");
    check(sFOR, "for");
    check(sIDENTIF, "variavel de controle");
    check(sATRIB, ":=");
    parse_expr();
    check(sTO, "to");
    parse_expr();
    if (la.categoria == sSTEP) {
        advance();
        if (la.categoria == sSUBRAT) advance();   /* passo negativo */
        if (la.categoria == sCTEINT || la.categoria == sIDENTIF)
            advance();
        else
            diag_error(la.linha, "passo (inteiro ou identificador)", &la);
    }
    check(sDO, "do");
    parse_cmd();
    exit_rule("fr");
}


static void parse_wh_body(void) {
    enter_rule("wh");
    check(sWHILE, "while");
    check(sABRE_PAR, "(");
    parse_expr();
    check(sFECHA_PAR, ")");
    parse_cmd();
    exit_rule("wh");
}


static void parse_rpt_body(void) {
    enter_rule("rpt");
    while (la.categoria != sUNTIL && la.categoria != sEOF) {
        parse_cmd();
        check(sPONTO_VIRG, ";");
    }
    check(sUNTIL, "until");
    check(sABRE_PAR, "(");
    parse_expr();
    check(sFECHA_PAR, ")");
    exit_rule("rpt");
}


static void parse_ret(void) {
    enter_rule("ret");
    check(sRET, "ret");
    parse_elem();
    exit_rule("ret");
}


static void parse_elem(void) {
    enter_rule("elem");
    if (la.categoria == sSTRING)
        advance();
    else
        parse_expr();
    exit_rule("elem");
}


static void parse_expr(void) {
    enter_rule("expr");
    parse_exlog();
    while (la.categoria == sOR) {
        advance();
        parse_exlog();
    }
    exit_rule("expr");
}

static void parse_exlog(void) {
    enter_rule("exlog");
    parse_exrel();
    while (la.categoria == sAND) {
        advance();
        parse_exrel();
    }
    exit_rule("exlog");
}

static void parse_exrel(void) {
    enter_rule("exrel");
    parse_exari();
    while (la.categoria == sMAIOR    || la.categoria == sMAIORIG ||
           la.categoria == sIGUAL   || la.categoria == sMENOR   ||
           la.categoria == sMENORIG || la.categoria == sDIFERENTE) {
        advance();
        parse_exari();
    }
    exit_rule("exrel");
}

static void parse_exari(void) {
    enter_rule("exari");
    parse_exarp();
    while (la.categoria == sSOMA || la.categoria == sSUBRAT) {
        advance();
        parse_exarp();
    }
    exit_rule("exari");
}

static void parse_exarp(void) {
    enter_rule("exarp");
    parse_fact();
    while (la.categoria == sMULT || la.categoria == sDIV) {
        advance();
        parse_fact();
    }
    exit_rule("exarp");
}

static void parse_fact(void) {
    enter_rule("fact");

    switch (la.categoria) {
        case sCTEINT:
        case sCTECHAR:
        case sTRUE:
        case sFALSE:
            advance();
            break;

        case sNEG:
            advance();
            parse_fact();
            break;

        case sSUBRAT:   
            advance();
            parse_fact();
            break;

        case sABRE_PAR:
            advance();
            parse_expr();
            check(sFECHA_PAR, ")");
            break;

        case sIDENTIF: {
            advance();
            if (la.categoria == sABRE_COLCH) {
                advance();
                if (la.categoria == sCTEINT || la.categoria == sIDENTIF)
                    advance();
                else
                    diag_error(la.linha, "indice (inteiro ou identificador)", &la);
                check(sFECHA_COLCH, "]");
            } else if (la.categoria == sABRE_PAR) {
                advance();
                if (la.categoria != sFECHA_PAR) {
                    parse_expr();
                    while (la.categoria == sVIRGULA) {
                        advance();
                        parse_expr();
                    }
                }
                check(sFECHA_PAR, ")");
            }
            break;
        }

        default:
            diag_error(la.linha, "fator de expressao", &la);
    }

    exit_rule("fact");
}
