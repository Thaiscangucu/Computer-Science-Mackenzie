// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#include "log.h"
#include "diag.h"
#include "symtab.h"
#include <stdio.h>
#include <string.h>

static FILE *tk_file  = NULL;
static FILE *ts_file  = NULL;
static FILE *trc_file = NULL;

void log_init(const char *basename, int tokens, int symtab, int trace) {
    char path[512];

    if (tokens) {
        snprintf(path, sizeof(path), "%s.tk", basename);
        tk_file = fopen(path, "w");
        if (!tk_file)
            fprintf(stderr, "Aviso: nao foi possivel criar %s\n", path);
    }
    if (symtab) {
        snprintf(path, sizeof(path), "%s.ts", basename);
        ts_file = fopen(path, "w");
        if (!ts_file)
            fprintf(stderr, "Aviso: nao foi possivel criar %s\n", path);
    }
    if (trace) {
        snprintf(path, sizeof(path), "%s.trc", basename);
        trc_file = fopen(path, "w");
        if (!trc_file)
            fprintf(stderr, "Aviso: nao foi possivel criar %s\n", path);
        diag_set_trace_file(trc_file);
    }
}


void log_token(const Token *t) {
    if (!tk_file) return;
    fprintf(tk_file, "%d %s \"%s\"\n",
            t->linha,
            diag_token_name(t->categoria),
            t->lexema);
}

void log_symtab(void) {
    if (ts_file)
        ts_print(ts_file);
}

void log_close(void) {
    if (tk_file)  { fclose(tk_file);  tk_file  = NULL; }
    if (ts_file)  { fclose(ts_file);  ts_file  = NULL; }
    if (trc_file) {
        diag_set_trace_file(NULL);
        fclose(trc_file);
        trc_file = NULL;
    }
}
