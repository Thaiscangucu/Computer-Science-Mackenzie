// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef DIAG_H
#define DIAG_H

#include <stdio.h>
#include "lex.h"

// Retorna o nome do enum de uma categoria de token
const char *diag_token_name(TokenType t);

void diag_error(int linha, const char *esperado, const Token *encontrado);

// --trace log
void diag_info(const char *fmt, ...);

// Configura o arquivo de saída do trace 
void diag_set_trace_file(FILE *f);

#endif
