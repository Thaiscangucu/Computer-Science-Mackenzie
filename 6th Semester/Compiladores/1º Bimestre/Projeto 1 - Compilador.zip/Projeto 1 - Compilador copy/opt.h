// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef OPT_H
#define OPT_H

#include <stdbool.h>

typedef struct {
    char *input_file;
    bool show_tokens;
    bool show_symtab;
    bool show_trace;
} Options;

// Funções públicas do módulo
void opts_parse(int argc, char *argv[]);
Options* opts_get(void);

#endif