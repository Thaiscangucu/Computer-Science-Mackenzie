// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#include <stdio.h>
#include <string.h>
#include "opt.h"
#include "lex.h"
#include "parser.h"
#include "symtab.h"
#include "diag.h"
#include "log.h"

int main(int argc, char *argv[]) {
    opts_parse(argc, argv);
    Options *cfg = opts_get();

    FILE *arq = fopen(cfg->input_file, "r");
    if (arq == NULL) {
        fprintf(stderr, "Erro: nao foi possivel abrir '%s'\n", cfg->input_file);
        return 1;
    }

    char base[512];
    strncpy(base, cfg->input_file, sizeof(base) - 1);
    base[sizeof(base) - 1] = '\0';
    char *dot = strrchr(base, '.');
    if (dot) *dot = '\0';

    ts_init();
    log_init(base, cfg->show_tokens, cfg->show_symtab, cfg->show_trace);
    lex_init(arq);

    // Executa a análise léxica + sintática + construção da TS. 
    parse_program();

    if (cfg->show_symtab) {
        printf("\n=== Tabela de Simbolos ===\n");
        ts_print(stdout);
        log_symtab();
    }

    log_close();
    fclose(arq);

    printf("Analise concluida com sucesso.\n");
    return 0;
}
