// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef SYMTAB_H
#define SYMTAB_H

#include <stdbool.h>
#include <stdio.h>

typedef enum {
    CAT_VAR,    
    CAT_PARAM,  
    CAT_PROC,   
    CAT_FUNC    
} SymCat;

typedef enum {
    TYP_INT,        
    TYP_BOOL,       
    TYP_CHAR,       
    TYP_ARRAY_INT, 
    TYP_ARRAY_BOOL,
    TYP_ARRAY_CHAR,
    TYP_NONE     
} SymType;

typedef enum {
    SCOPE_GLOBAL,   
    SCOPE_LOCAL     
} SymScope;

typedef struct {
    char     name[256];        
    SymCat   cat;              
    SymType  type;             
    SymScope scope;           
    int      level;           
    int      extra;            
    char     scope_path[128];  
} Symbol;

void ts_init(void);

void ts_open_scope(void);
void ts_close_scope(void);

void ts_set_scope_path(const char *path);

bool ts_insert(const char *name, SymCat cat, SymType type, SymScope scope, int extra);

Symbol *ts_lookup(const char *name);

void ts_print(FILE *out);

int ts_current_level(void);

const char *ts_cat_name(SymCat c);
const char *ts_type_name(SymType t);

#endif 
