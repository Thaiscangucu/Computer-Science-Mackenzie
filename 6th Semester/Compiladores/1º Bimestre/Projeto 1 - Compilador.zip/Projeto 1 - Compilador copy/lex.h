// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef LEX_H
#define LEX_H

#include <stdio.h>

typedef enum {
    // Identificadores e constantes 
    sIDENTIF, sCTEINT, sCTECHAR, sSTRING,

    // Palavras reservadas 
    sBOOL, sCHAR, sINT,
    sIF, sELSE,
    sWHILE, sLOOP, sUNTIL,
    sFOR, sTO, sSTEP, sDO,
    sMATCH, sWHEN, sOTHERWISE,
    sSTART, sEND,
    sGLOBALS, sLOCALS,
    sFN, sPROC, sRET,
    sPRINT, sSCAN,
    sTRUE, sFALSE,
    sMODULE, sMAIN,

    // Operadores aritméticos
    sSOMA, sSUBRAT, sMULT, sDIV,

    // Operadores relacionais
    sIGUAL, sDIFERENTE, sMAIOR, sMAIORIG, sMENOR, sMENORIG,

    // Operadores lógicos
    sAND, sOR, sNEG,

    // Operadores compostos 
    sATRIB,       
    sPTOPTO,      
    sIMPLIC,      

    // Delimitadores simples 
    sPONTO_VIRG, sVIRGULA, sDOIS_PONTOS,
    sABRE_PAR, sFECHA_PAR,
    sABRE_COLCH, sFECHA_COLCH,

    // Controle
    sEOF, sERRO
} TokenType;

typedef struct {
    TokenType categoria;
    char      lexema[256];
    int       linha;
} Token;

void  lex_init(FILE *f);
Token lex_next(void);
int   lex_line(void);

#endif
