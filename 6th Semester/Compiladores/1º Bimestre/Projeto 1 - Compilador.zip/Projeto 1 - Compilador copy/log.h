// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#ifndef LOG_H
#define LOG_H

#include "lex.h"


void log_init(const char *basename, int tokens, int symtab, int trace);

// Registra um token no arquivo .tk 
void log_token(const Token *t);

void log_symtab(void);

void log_close(void);

#endif 
