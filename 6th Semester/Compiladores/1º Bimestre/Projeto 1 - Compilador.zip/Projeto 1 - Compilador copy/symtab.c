// Projeto de Compiladores 06N 2026
// Miguel Piñeiro Coratolo Simões - 10427085
// Thais Ferreira Canguçu - 10403283

#include "symtab.h"
#include <string.h>
#include <stdio.h>

#define MAX_SYMBOLS     1024
#define MAX_SCOPE_DEPTH   64

static Symbol table[MAX_SYMBOLS];
static int    count     = 0;
static int    cur_level = 0;


static int scope_start[MAX_SCOPE_DEPTH];
static int scope_depth  = 0;

static char cur_scope_path[128] = "global";

void ts_init(void) {
    count       = 0;
    cur_level   = 0;
    scope_depth = 0;
    scope_start[0] = 0;
    strncpy(cur_scope_path, "global", sizeof(cur_scope_path) - 1);
}

void ts_open_scope(void) {
    cur_level++;
    if (scope_depth < MAX_SCOPE_DEPTH)
        scope_start[scope_depth++] = count;
}

void ts_close_scope(void) {
    if (scope_depth > 0) scope_depth--;
    if (cur_level  > 0) cur_level--;
    strncpy(cur_scope_path, "global", sizeof(cur_scope_path) - 1);
}

void ts_set_scope_path(const char *path) {
    strncpy(cur_scope_path, path, sizeof(cur_scope_path) - 1);
    cur_scope_path[sizeof(cur_scope_path) - 1] = '\0';
}

int ts_current_level(void) {
    return cur_level;
}

bool ts_insert(const char *name, SymCat cat, SymType type, SymScope scope, int extra) {
    int start = (scope_depth > 0) ? scope_start[scope_depth - 1] : 0;
    for (int i = start; i < count; i++) {
        if (strcmp(table[i].name, name) == 0)
            return false;
    }
    if (count >= MAX_SYMBOLS) return false;

    int level = (scope == SCOPE_GLOBAL) ? 0 : cur_level;

    strncpy(table[count].name, name, 255);
    table[count].name[255] = '\0';
    table[count].cat   = cat;
    table[count].type  = type;
    table[count].scope = scope;
    table[count].level = level;
    table[count].extra = extra;

    if (scope == SCOPE_GLOBAL)
        strncpy(table[count].scope_path, "global", 127);
    else
        strncpy(table[count].scope_path, cur_scope_path, 127);
    table[count].scope_path[127] = '\0';

    count++;
    return true;
}

Symbol *ts_lookup(const char *name) {
    for (int i = count - 1; i >= 0; i--) {
        if (strcmp(table[i].name, name) == 0)
            return &table[i];
    }
    return NULL;
}

const char *ts_cat_name(SymCat c) {
    switch (c) {
        case CAT_VAR:   return "var";
        case CAT_PARAM: return "param";
        case CAT_PROC:  return "proc";
        case CAT_FUNC:  return "func";
        default:        return "?";
    }
}

const char *ts_type_name(SymType t) {
    switch (t) {
        case TYP_INT:        return "int";
        case TYP_BOOL:       return "bool";
        case TYP_CHAR:       return "char";
        case TYP_ARRAY_INT:  return "int[]";
        case TYP_ARRAY_BOOL: return "bool[]";
        case TYP_ARRAY_CHAR: return "char[]";
        case TYP_NONE:       return "none";
        default:             return "?";
    }
}

void ts_print(FILE *out) {
    for (int i = 0; i < count; i++) {
        const Symbol *s = &table[i];
        fprintf(out,
                "SCOPE=%-24s id=\"%-20s\" cat=%-6s tipo=%-8s extra=%d\n",
                s->scope_path,
                s->name,
                ts_cat_name(s->cat),
                ts_type_name(s->type),
                s->extra);
    }
}
